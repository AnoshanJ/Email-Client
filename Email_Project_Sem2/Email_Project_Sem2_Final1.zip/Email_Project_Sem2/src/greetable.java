public interface greetable {

    public String getBirthday();
    public String getGreeting();

    public boolean isBirthday(String date);

}
